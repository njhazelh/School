#Single Cycle MIPS Processor
##Nicholas Jones, Jason Chin
============================

To simulate run singleCycleCPU_tb.v for at least 11 us. It will stop at 10us.

Note, the program stops at about 10 us.  The final value is written to register
24 very close to this time, so you have to be very precise with your clicking
to see the right value.  A png has been provided showing our results.