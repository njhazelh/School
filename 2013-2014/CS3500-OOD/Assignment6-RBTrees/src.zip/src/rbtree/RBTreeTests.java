/* Name: Nicholas Jones
 * Email: njhazelh@zimbra.ccs.neu.edu
 * Comments: 
 */
package rbtree;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author Nicholas Jones
 * @version Nov 1, 2013
 */
public class RBTreeTests {
    
    /**
     * Test something.
     */
    @Test
    public void test() {
        assertTrue("", true);
    }
    
}
